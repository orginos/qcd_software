#ifdef SREAL
   #include "atlas_sr2.h"
#elif defined(DREAL)
   #include "atlas_dr2.h"
#elif defined(SCPLX)
   #include "atlas_cr2.h"
#elif defined(DCPLX)
   #include "atlas_zr2.h"
#endif
