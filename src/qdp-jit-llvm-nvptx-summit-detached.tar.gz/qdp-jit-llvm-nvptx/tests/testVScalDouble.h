#ifndef TEST_VScal
#define TEST_VScal


#ifndef UNITTEST_H
#include "unittest.h"
#endif


class testVScal4_1 : public TestFixture { public: void run(void); };
class testVScal4_2 : public TestFixture { public: void run(void); };
class testVScal4_3 : public TestFixture { public: void run(void); };



#endif
