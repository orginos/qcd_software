#ifndef TEST_LocalVcdotReal_DOUBLE
#define TEST_LocalVcdotReal_DOUBLE


#ifndef UNITTEST_H
#include "unittest.h"
#endif


class testLocalVcdotReal4_1 : public TestFixture { public: void run(void); };
class testLocalVcdotReal4_2 : public TestFixture { public: void run(void); };
class testLocalVcdotReal4_3 : public TestFixture { public: void run(void); };



#endif
