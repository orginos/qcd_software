#ifndef TEST_LocalVcdot_DOUBLE
#define TEST_LocalVcdot_DOUBLE


#ifndef UNITTEST_H
#include "unittest.h"
#endif


class testLocalVcdot4_1 : public TestFixture { public: void run(void); };
class testLocalVcdot4_2 : public TestFixture { public: void run(void); };
class testLocalVcdot4_3 : public TestFixture { public: void run(void); };



#endif
