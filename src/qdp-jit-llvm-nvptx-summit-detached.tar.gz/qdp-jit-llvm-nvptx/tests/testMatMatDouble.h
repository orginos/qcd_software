#ifndef TEST_MATMAT_DOUBLE
#define TEST_MATMAT_DOUBLE


#ifndef UNITTEST_H
#include "unittest.h"
#endif


class testSSEDScalMult1_1  : public TestFixture { public: void run(void); };
class testSSEDScalMult1_2  : public TestFixture { public: void run(void); };
class testSSEDScalMult1_2  : public TestFixture { public: void run(void); };

class testSSEDScalMult2_1  : public TestFixture { public: void run(void); };
class testSSEDScalMult2_2  : public TestFixture { public: void run(void); };
class testSSEDScalMult2_3  : public TestFixture { public: void run(void); };


#endif
