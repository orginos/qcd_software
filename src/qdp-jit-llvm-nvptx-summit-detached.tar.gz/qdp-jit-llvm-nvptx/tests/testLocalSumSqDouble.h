#ifndef TEST_LocalSumSq_DOUBLE
#define TEST_LocalSumSq_DOUBLE


#ifndef UNITTEST_H
#include "unittest.h"
#endif


class testLocalSumSq4_1 : public TestFixture { public: void run(void); };
class testLocalSumSq4_2 : public TestFixture { public: void run(void); };
class testLocalSumSq4_3 : public TestFixture { public: void run(void); };



#endif
