//
// QDP data parallel interface
//

#include "qdp.h"

namespace QDP {

  Zero zero;

// Currently empty

} // namespace QDP;
