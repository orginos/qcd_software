#ifndef qdp_libdevice
#define qdp_libdevice

namespace QDP {
namespace LIBDEVICE {

extern unsigned char libdevice_bc[];
extern unsigned int libdevice_bc_len;

} // namespace LIBDEVICE
} // namespace QDP
#endif
