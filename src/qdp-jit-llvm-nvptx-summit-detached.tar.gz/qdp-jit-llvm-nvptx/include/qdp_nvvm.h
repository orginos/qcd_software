
namespace QDP {

  std::string nvvm_compile(const char* ll_kernel_fname);

} // namespace QDP
